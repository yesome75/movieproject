CREATE TABLE customer( 
	cid VARCHAR(100) PRIMARY KEY, -- 회원 아이디
	cname VARCHAR(100), -- 회원 이름
	cpassword VARCHAR(100), -- 회원 비밀번호
	cemail VARCHAR(100), -- 회원 이메일 
	cphone VARCHAR(100), -- 회원 전화번호 
	cdel VARCHAR(100), --삭제
	creg_date VARCHAR(100),
	cbirthday VARCHAR(100) -- 회원 생일 
);
select * from booking;
create table booking(
	bid number not null,
	cid VARCHAR(100) PRIMARY KEY,
	lid number not null,
	tid number not null,
	mid number not null,
	rtid number not null,
	ticketnumber VARCHAR(100),
	pid number not null,
	bseat VARCHAR(100),
	bdate date,
	bdel VARCHAR(100)
);
create table location(
	lid number PRIMARY KEY, 
	lname VARCHAR(100),
	laddress VARCHAR(100),
	lphone VARCHAR(100),
	lat number not null,  // 위도
	lon number not null, // 경도
	mid number not null
);
create table movie(
	mid number not null,
	mtitle VARCHAR(100),
	moriginaltitle VARCHAR(100),//원제
	mdirector VARCHAR(100),
	mactor VARCHAR(100),
	mcontent VARCHAR(100),
	mreleaseDate date,//개봉일
	mrunningTime number not null,
	murlPreview VARCHAR(100),
	murlPosterVARCHAR(100),
	mgrade VARCHAR(100),//상영등급
	mnation VARCHAR(100),// 만든 나라
	mdel VARCHAR(100)
);