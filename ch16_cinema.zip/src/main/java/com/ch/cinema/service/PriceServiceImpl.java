package com.ch.cinema.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
//import com.ch.cinema.service.PriceDao;

import com.ch.cinema.dao.PriceDao;


@Service
public class PriceServiceImpl implements PriceService{
	@Autowired
	private PriceDao pd;
}
