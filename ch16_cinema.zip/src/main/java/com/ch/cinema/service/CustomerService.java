package com.ch.cinema.service;

import com.ch.cinema.model.Customer;

public interface CustomerService {

	Customer getSessionInfo(String id);

	int loginCheck(Customer customer);

	Customer joinCheck(Customer customer);

	Customer idDupCheck(String cid);

	int insertCustomer(Customer customer);


}