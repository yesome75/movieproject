package com.ch.cinema.service;

public interface PriceService {

}
