package com.ch.cinema.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.cinema.dao.CustomerDao;
import com.ch.cinema.model.Customer;
@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	private CustomerDao cd;
	public int loginCheck(Customer customer) {
		
		return cd.loginCheck(customer);
	}
	public Customer getSessionInfo(String id) {
		
		return cd.getSessionInfo(id);
	}

	public Customer joinCheck(Customer customer) {
		
		return cd.joinCheck(customer);
	}

	public Customer idDupCheck(String cid) {
		
		return cd.idDupCheck(cid);
	}

	public int insertCustomer(Customer customer) {
		
		return cd.insertCustomer(customer);
	}

}