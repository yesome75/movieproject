package com.ch.cinema.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ch.cinema.dao.BookingDao;
import com.ch.cinema.model.Location;
import com.ch.cinema.model.Movie;
import com.ch.cinema.model.RunningtimeTable;

@Service
public class BookingServiceImpl implements BookingService {
	@Autowired
	private BookingDao bd;

	@Override
	public List<Movie> movieList() {
		return bd.movieList();
	}

	public List<Location> locationList(int mid) {
		return bd.locationList(mid);
	}
	public List<RunningtimeTable> dateList(int mid, int lid) {
		return bd.dateList(mid,lid);
	}

}
