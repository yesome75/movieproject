package com.ch.cinema.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import com.ch.cinema.service.PriceService;

@Controller
public class PriceController {
	@Autowired
	private PriceService ps;

}
