package com.ch.cinema.controller;

import org.springframework.beans.factory.annotation.Autowired;

import com.ch.cinema.service.LocationService;
import com.ch.cinema.service.MovieService;
import com.ch.cinema.service.TheaterService;

@org.springframework.stereotype.Controller
public class AdminController {
	@Autowired
	private LocationService ls;
	private MovieService ms;
	private TheaterService ts;

}
