package com.ch.cinema.dao;

import java.util.HashMap;
import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.parsing.Location;
import org.springframework.stereotype.Repository;
import com.ch.cinema.model.Movie;
import com.ch.cinema.model.RunningtimeTable;


@Repository
public class BookingDaoImpl implements BookingDao{
	@Autowired
	private SqlSessionTemplate sst;

	@Override
	public List<Movie> movieList() {
		return sst.selectList("moviens.list");
	}

	public List<Location> locationList(int mid) {
		return sst.selectList("locationns.list",mid);
	}
	public List<RunningtimeTable> dateList(int mid, int lid) {
		HashMap<String , Integer> date=new HashMap<String, Integer>();
		date.put("mid", mid);
		date.put("lid", lid);
		return sst.selectList("runningtimetablens.list", date);
	}
}
