package com.ch.cinema.dao;

import com.ch.cinema.model.Customer;

public interface CustomerDao {
	int loginCheck(Customer customer);
	Customer getSessionInfo(String id);
	Customer joinCheck(Customer customer);
	Customer idDupCheck(String cid);
	int insertCustomer(Customer customer);
}
