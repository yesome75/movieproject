package com.ch.cinema.dao;

public interface LocationDao {

}
