package com.ch.cinema.dao;

import java.util.List;
import com.ch.cinema.model.Movie;
import com.ch.cinema.model.Location;
import com.ch.cinema.model.RunningtimeTable;

public interface BookingDao {

	List<Movie> movieList();
	List<Location> locationList(int mid);
	List<RunningtimeTable> dateList(int mid, int lid);

}
