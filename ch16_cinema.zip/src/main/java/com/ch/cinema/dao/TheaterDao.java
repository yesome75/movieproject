package com.ch.cinema.dao;

public interface TheaterDao {

}
